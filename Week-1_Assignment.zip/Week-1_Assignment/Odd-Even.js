//To  check if the given number is odd or even 
function isOddOrEven(num) {
    if(num%2==0){
        console.log("The number", num ,"is a Even number");
    } else{
        console.log("The number", num ,"is Odd number");
    }
    
}
let num = 50;
isOddOrEven(num);

