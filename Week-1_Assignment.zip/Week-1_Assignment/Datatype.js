var firstName = 'Eric'
console.log(typeof firstName);

var companyName = 'Amazon'
console.log(typeof companyName);



var mobileNumber = 992348588
console.log(typeof mobileNumber);



var isAutomation = true
console.log(typeof isAutomation);


var isAutomations
console.log(typeof isAutomations);


var isflakiness = null
console.log(typeof isflakiness);


